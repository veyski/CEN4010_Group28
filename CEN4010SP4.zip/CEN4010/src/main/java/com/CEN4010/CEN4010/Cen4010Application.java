package com.CEN4010.CEN4010;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cen4010Application {

	public static void main(String[] args) {
		SpringApplication.run(Cen4010Application.class, args);
	}

}
