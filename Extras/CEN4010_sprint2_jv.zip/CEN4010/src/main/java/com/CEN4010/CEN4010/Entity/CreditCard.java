package com.CEN4010.CEN4010.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "credit_card")

@NoArgsConstructor
@AllArgsConstructor
public class CreditCard {
    @Id
    @Column(name = "CreditCard_Number")
    private int creditCard_Number;

    @Column(name = "BankName")
    private int bankName;

    /*
   @Column(name = "username")
  private int username;
    */

}
