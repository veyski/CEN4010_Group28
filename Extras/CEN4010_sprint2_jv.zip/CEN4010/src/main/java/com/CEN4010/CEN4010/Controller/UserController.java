package com.CEN4010.CEN4010.Controller;

import com.CEN4010.CEN4010.Entity.User;
import com.CEN4010.CEN4010.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {
    @Autowired
    private UserService userService;
    @PostMapping("/addUser")
    public User postDetails(@RequestBody User user)
    {
        return userService.save(user);
    }

    @GetMapping("/getUser")
    public List<User> getDetails()
    {
        return userService.getAllDetails();

    }

}
